# Poker_hand_detector > 2025-06-26 12:55am
https://universe.roboflow.com/mait-d3mmv/poker_hand_detector-rypqv

Provided by a Roboflow user
License: CC BY 4.0

